# pip install pyserial

import serial
Ser = serial.Serial('COM7', baudrate=9600)

def control(command):
    if 'low' in command:
        Ser.write(b'L')
    if 'medium' in command:
        Ser.write(b'M')
    if 'full' in command:
        Ser.write(b'F')
    if 'off' in command:
        Ser.write(b'O')

while True:
    command =input("enter on to turn on FAN & off tO turn off FAN: ")
    control(command)

