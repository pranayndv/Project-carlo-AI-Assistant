import pyautogui
from time import sleep

sleep(5)
kkk = pyautogui.position()
print(kkk)
