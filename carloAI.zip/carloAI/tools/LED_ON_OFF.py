# pip install pyserial

import serial
Ser = serial.Serial('COM7', baudrate=9600)

def control(command):
    if 'on' in command:
        Ser.write(b'Y')
    if 'off' in command:
        Ser.write(b'N')

while True:
    command =input("enter on to turn on LED & off tO turn off LED: ")
    control(command)


